# GrapeMC - Next.js + Tailwind Template

This repo is a Vercel-ready Next.js App Router template for a Minecraft server landing page.
Theme: Blue + Cyan neon glow. Tailwind + custom CSS for glassmorphism and neon glows.

## How to use
1. unzip `GrapeMC.zip`
2. `cd grapemc`
3. `npm install`
4. `npm run dev` (local)
5. Push to GitHub and import to Vercel — build & deploy should work out of the box.

## What's included
- Next.js App Router structure (`/app`)
- Tailwind CSS configured
- GlowTitle component + Copy IP button
- Placeholder `public/logo.png` (replace with your real logo)
- Discord link set to: https://discord.gg/sAKN5pf3aM

Enjoy — customize ranks, copy IP text, and colors from `styles/globals.css` & `tailwind.config.js`.
