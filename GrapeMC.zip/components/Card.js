export default function Card({ title, children, subtitle }) {
  return (
    <div className="card-glass shadow-neon">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm opacity-70">{subtitle}</div>
          <div className="text-lg font-semibold mt-1">{title}</div>
        </div>
      </div>
      <div className="mt-4 text-sm opacity-80">
        {children}
      </div>
    </div>
  )
}
