'use client'
import { useState } from 'react';

export default function CopyIPButton({ ip = 'play.grapemc.fun' }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(ip);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      alert('Could not copy — your browser may block clipboard access.');
    }
  }

  return (
    <button onClick={handleCopy} className="btn btn-primary" title="Copy server IP">
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-3-3v6" /></svg>
      {copied ? 'Copied!' : ip}
    </button>
  )
}
