export default function GlowTitle({ children, color = 'blue', className = '' }) {
  const map = {
    blue: 'glow-blue',
    cyan: 'glow-cyan',
    red: 'glow-red'
  }
  const c = map[color] || map.blue
  return (
    <h1 className={`text-4xl md:text-6xl font-extrabold ${c} ${className}`}>
      {children}
    </h1>
  )
}
