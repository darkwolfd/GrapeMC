import Image from 'next/image'
import GlowTitle from '../components/GlowTitle'
import Card from '../components/Card'
import CopyIPButton from '../components/CopyIPButton'

export default function Home() {
  return (
    <div className="flex-1 flex flex-col py-20">
      <div className="container">
        <header className="flex items-center justify-between mb-12">
          <div className="flex items-center gap-4">
            <Image src="/logo.png" alt="GrapeMC" width={88} height={88} className="logo-placeholder rounded-md" />
            <div>
              <div className="kicker">GrapeMC</div>
              <div className="text-sm opacity-70">Modern Minecraft server</div>
            </div>
          </div>
          <nav className="flex items-center gap-3">
            <a href="#play" className="btn btn-primary">Play Now</a>
            <a href="https://discord.gg/sAKN5pf3aM" target="_blank" rel="noreferrer" className="btn btn-ghost">Join Discord</a>
          </nav>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
          <div className="md:col-span-2">
            <div className="mb-6">
              <GlowTitle color="blue" className="neon-underline">GrapeMC</GlowTitle>
              <p className="mt-4 text-gray-300 max-w-xl">
                Welcome to GrapeMC — clean, fast, and community-driven Minecraft experience.
                Neon vibes, stable gameplay, and custom features. Join now and play with friends.
              </p>
              <div className="mt-6 flex gap-3">
                <a href="#play" className="btn btn-primary">Play Now</a>
                <a href="https://discord.gg/sAKN5pf3aM" className="btn btn-ghost">Join Discord</a>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card title="Rank: Explorer" subtitle="Rank 1">
                Basic rank with starter kit. Edit this later from components.
              </Card>
              <Card title="Rank: Builder" subtitle="Rank 2">
                Mid-tier perks and claim tools. Replace text as needed.
              </Card>
              <Card title="Rank: Elite" subtitle="Rank 3">
                VIP perks, dedicated slots, custom cosmetics.
              </Card>
            </div>

            <div className="mt-8 card-glass">
              <h3 className="text-lg font-semibold glow-cyan">YouTube</h3>
              <p className="mt-2 opacity-80">Coming Soon — subscribe and catch our guides & montages.</p>
            </div>
          </div>

          <aside>
            <div className="space-y-4">
              <div className="card-glass">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="kicker">Server IP</div>
                    <div className="text-xl font-bold mt-1 ip-badge">play.grapemc.fun</div>
                  </div>
                  <div>
                    <CopyIPButton ip="play.grapemc.fun" />
                  </div>
                </div>
                <p className="mt-3 text-sm opacity-80">Join using Minecraft Java edition — port 25565.</p>
              </div>

              <div className="card-glass">
                <h4 className="font-semibold">Discord</h4>
                <p className="mt-2 text-sm opacity-80">Community hub for announcements, staff apps, and events.</p>
                <a href="https://discord.gg/sAKN5pf3aM" target="_blank" rel="noreferrer" className="mt-4 inline-block btn btn-primary">Open Discord</a>
              </div>

              <div className="card-glass text-center">
                <h4 className="font-semibold">Quick Actions</h4>
                <div className="mt-3 flex flex-col gap-2">
                  <a href="#ranks" className="btn btn-ghost">See Ranks</a>
                  <a href="#youtube" className="btn btn-ghost">YouTube</a>
                </div>
              </div>
            </div>
          </aside>
        </section>

        <footer className="mt-12 border-t border-white/6 pt-6 flex items-center justify-between">
          <div className="footer">© {new Date().getFullYear()} GrapeMC — All rights reserved</div>
          <div className="footer">
            <a href="https://discord.gg/sAKN5pf3aM" target="_blank" rel="noreferrer">Discord</a>
          </div>
        </footer>
      </div>
    </div>
  )
}
